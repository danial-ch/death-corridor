package ir.ac.kntu;

public class AssaultRifle extends Gun {

    public AssaultRifle() {
        this.damage=10;
        this.hitRate=50;
    }
}
